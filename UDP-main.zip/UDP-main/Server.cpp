#include <iostream>
#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment(lib, "ws2_32.lib")

using namespace std;

struct Student
{
    char name[64];
    char faculty[64];
    int marks[4];
};

enum Scholarship
{
    NO = 0,
    ORDINARY = 1,
    HIGH = 2
};

int main()
{
    setlocale(LC_ALL, "Russian");

    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
    {
        cout << "WSAStartup error\n";
        return 1;
    }

    SOCKET serverSocket = socket(AF_INET, SOCK_DGRAM, 0);

    sockaddr_in serverAddr{};
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(12345);
    serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);

    if (bind(serverSocket, (sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR)
    {
        cout << "Bind error\n";
        return 1;
    }

    cout << "UDP сервер запущен...\n";

    while (true)  // сервер работает всегда
    {
        sockaddr_in clientAddr{};
        int clientAddrSize = sizeof(clientAddr);

        Student st{};
        int received = recvfrom(
            serverSocket,
            (char*)&st,
            sizeof(st),
            0,
            (sockaddr*)&clientAddr,
            &clientAddrSize
        );

        if (received <= 0)
            continue;

        cout << "\nЗапрос от клиента:\n";
        cout << "ФИО: " << st.name << endl;
        cout << "Факультет: " << st.faculty << endl;
        cout << "Оценки: ";
        for (int i = 0; i < 4; i++)
            cout << st.marks[i] << " ";
        cout << endl;

        bool hasLow = false;
        int sum = 0;

        for (int i = 0; i < 4; i++)
        {
            if (st.marks[i] <= 3)
                hasLow = true;
            sum += st.marks[i];
        }

        Scholarship result;
        if (hasLow)
            result = NO;
        else if (sum == 20)
            result = HIGH;
        else
            result = ORDINARY;

        sendto(
            serverSocket,
            (char*)&result,
            sizeof(result),
            0,
            (sockaddr*)&clientAddr,
            clientAddrSize
        );
    }

    closesocket(serverSocket);
    WSACleanup();
}
