#include <iostream>
#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment(lib, "ws2_32.lib")

using namespace std;

struct Student
{
    char name[64];
    char faculty[64];
    int marks[4];
};

enum Scholarship
{
    NO = 0,
    ORDINARY = 1,
    HIGH = 2
};

int main()
{
    setlocale(LC_ALL, "Russian");

    WSADATA wsa;
    WSAStartup(MAKEWORD(2, 2), &wsa);

    SOCKET clientSocket = socket(AF_INET, SOCK_DGRAM, 0);

    sockaddr_in serverAddr{};
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(12345);
    inet_pton(AF_INET, "127.0.0.1", &serverAddr.sin_addr);

    while (true)
    {
        Student st{};

        cout << "\nВведите ФИО (exit для выхода): ";
        cin.getline(st.name, 64);
        if (string(st.name) == "exit")
            break;

        cout << "Введите факультет: ";
        cin.getline(st.faculty, 64);

        cout << "Введите 4 оценки: ";
        for (int i = 0; i < 4; i++)
            cin >> st.marks[i];
        cin.ignore();

        sendto(
            clientSocket,
            (char*)&st,
            sizeof(st),
            0,
            (sockaddr*)&serverAddr,
            sizeof(serverAddr)
        );

        Scholarship result;
        int serverAddrSize = sizeof(serverAddr);

        recvfrom(
            clientSocket,
            (char*)&result,
            sizeof(result),
            0,
            (sockaddr*)&serverAddr,
            &serverAddrSize
        );

        if (result == NO)
            cout << "Стипендия: нет\n";
        else if (result == ORDINARY)
            cout << "Стипендия: обычная\n";
        else
            cout << "Стипендия: повышенная\n";
    }

    closesocket(clientSocket);
    WSACleanup();
}
